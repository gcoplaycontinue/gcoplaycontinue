# TV Help Desk

English static help site. Open index.html in a browser for a local preview.

## Publish on GitHub Pages

1. Upload index.html to the root of a GitHub repository. Use a public repository if you are on GitHub Free.
2. In repository Settings → Pages, choose Deploy from a branch → main → /(root) and save. Check the github.io URL.
3. Verify ownership of gco-playcontinue.com with GitHub using the TXT record shown under account Settings → Pages. Then add gco-playcontinue.com under the repository’s Settings → Pages → Custom domain.
4. At your DNS provider, add four A records for the root host (@), one per value: 185.199.108.153, 185.199.109.153, 185.199.110.153, and 185.199.111.153. If the root already serves a site, the DNS cutover replaces its public destination. Review any overlapping web records before the switch.
5. When GitHub reports a successful DNS check, enable Enforce HTTPS and test https://gco-playcontinue.com/.

[GitHub Pages custom domain documentation](https://docs.github.com/en/pages/configuring-a-custom-domain-for-your-github-pages-site/managing-a-custom-domain-for-your-github-pages-site)
